
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";


const firebaseConfig = {
 apiKey: "AIzaSyBJthfSF_RV9q85ZUjxCWLt8ihi2RfWaGA",
 authDomain: "photofolio-95b32.firebaseapp.com",
 projectId: "photofolio-95b32",
 storageBucket: "photofolio-95b32.appspot.com",
 messagingSenderId: "970453496607",
 appId: "1:970453496607:web:e3090f5a85fdcf5b18f62a",
 measurementId: "G-VH54T0C4X1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getAnalytics(app);

export {db};