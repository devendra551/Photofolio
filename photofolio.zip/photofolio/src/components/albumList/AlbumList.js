import styles from "./albumsList.module.css";
import { useState, useEffect } from "react";
import { toast } from "react-toastify";
import Spinner from "react-spinner-material";

// firebase imports
import {
  collection,
  getDocs,
  addDoc,
  Timestamp,
  query,
  orderBy,
} from "firebase/firestore";
import { db } from "../../firebase";

// components imports
import { AlbumForm } from '../albumForm/AlbumForm';
import { ImagesList } from "../imagesList/ImagesList";

// mock data
// import { albumsData } from "../../static/mock";

export const AlbumsList = () => {
  const [albums, setAlbums] = useState([]);
  const [loading, setLoading] = useState(false);

  const [albumAddLoading, setAlbumAddLoading] = useState(false);

  const getAlbums = async ()=>{
    setLoading(true);
    const albumsRef = collection(db,"albums");
    const albumsSnapshot = await getDocs(
      query(albumsRef,orderBy("created","desc"))
    );

    const albumsData = albumsSnapshot.docs.map((doc)=>({
        id:doc.id,
        ...doc.data(),
    }));

    setAlbums(albumsData);
    setLoading(false);
  } ;
  
    useEffect(()=>{
      getAlbums();
    },[]);


    const handleAdd = async (name) =>{
      if(albums.find((a)=> a.name===name))
      return toast.error("Album name already in use");
      setAlbumAddLoading(true);
    }
}
